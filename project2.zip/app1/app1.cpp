#include <iostream>
#include "math_lib.h"
#include "data_structure_lib.h"

int main() {
    // Create an instance of MathLib
    MathLib mathLib;

    // Perform addition operation using math_lib
    int result_addition = mathLib.addition(3, 4);
    int result_multiplication = mathLib.multiplication(3, 4);

    // Print the results of operation
    std::cout<< "Usage of math_lib" <<std::endl;
    std::cout << "Result of addition: " << result_addition << std::endl;
    std::cout << "Result of multiplication: " << result_multiplication << std::endl;


    // Create an instance of LinkedList from data_structure_lib
    LinkedList linkedList;

    // Insert some elements into the linked list
    linkedList.insert(10);
    linkedList.insert(20);
    linkedList.insert(30);

    // Display the contents of the linked list
    std::cout<< "Usage of data_structure_lib" <<std::endl;
    std::cout << "Contents of the linked list: ";
    linkedList.display();

    return 0;
}
