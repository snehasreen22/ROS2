#include <opencv2/opencv.hpp>

int main() {
    // Read input image
    cv::Mat inputImage = cv::imread("input_image.jpg", cv::IMREAD_COLOR);
    if (inputImage.empty()) {
        std::cerr << "Error: Could not read the input image!" << std::endl;
        return 1;
    }

    // Perform image processing operations (e.g., apply filters, transformations, etc.)
    // For demonstration, let's convert the image to grayscale
    cv::Mat processedImage;
    cv::cvtColor(inputImage, processedImage, cv::COLOR_BGR2GRAY);

    // Save the processed image
    cv::imwrite("output_image.jpg", processedImage);

    return 0;
}
