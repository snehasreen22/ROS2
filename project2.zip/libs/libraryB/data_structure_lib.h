// data_structure_lib.h
#ifndef DATA_STRUCTURE_LIB_H
#define DATA_STRUCTURE_LIB_H

// Define your data structure interface here
class LinkedList {
private:
    struct Node {
        int data;
        Node* next;
        Node(int data) : data(data), next(nullptr) {}
    };
    Node* head;

public:
    LinkedList();
    ~LinkedList();
    void insert(int data);
    void display();
};

#endif
