// math_lib.h
#ifndef MATH_LIB_H
#define MATH_LIB_H

class MathLib {
public:
    int addition(int a, int b);
    int multiplication(int a, int b);
};

#endif
