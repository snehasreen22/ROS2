// math_lib.cpp
#include "math_lib.h"

int MathLib::addition(int a, int b) {
    return a + b;
}

int MathLib::multiplication(int a, int b) {
    return a * b;
}
